 #!/bin/sh
./server &
i="0"
while [ $i -lt 10 ]
do
./client read_from.txt write_to.txt
sleep 1
i=$[$i+1]
done
