# Execute the program with apparmor enabled 
#!/bin/sh
./server &
sleep 1
./client read_from.txt write_to.txt
