# Compiles all the 4 programs in the folder
#!/bin/sh
gcc server.c -o server
gcc serverb.c -o serverb
gcc client.c -o client
gcc clientb.c -o clientb
