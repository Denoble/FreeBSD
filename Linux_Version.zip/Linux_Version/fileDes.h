
#include<stdlib.h>
#define DATAMAX 50

 typedef struct{
	 int fileDesRd;
	 int fileDesWr;
	 char data[DATAMAX];
	char rdFileName[DATAMAX];
	char wrFileName[DATAMAX];
	
 }SocketMessage;
