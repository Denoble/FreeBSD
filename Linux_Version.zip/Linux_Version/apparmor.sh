#Enable apparmor profile 
#!/bin/sh
sudo aa-genprof client
sudo aa-genprof server
sudo aa-complain server
sudo aa-complain client
