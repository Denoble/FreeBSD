#Executes the program without Apparmor enabled 
#!/bin/sh
./serverb &
sleep 1
./clientb read_from.txt write_to.txt
