#!/bin/sh
./serverb &
i="0"
while [ $i -lt 10 ]
do
./clientb read_from.txt write_to.txt
sleep 1
i=$[$i+1]
done
