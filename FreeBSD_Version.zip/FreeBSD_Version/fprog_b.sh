# Runs the server / client program on FreeBSD without CAP_ENTER enabled
#!/bin/bash

./serverb &
sleep 1
./clientb read_from.txt write_to.txt

